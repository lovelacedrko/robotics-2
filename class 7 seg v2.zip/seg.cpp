#include "seg.h"


seg::seg(int pins[7]){
   this->pins = pins;
}

void seg::init(){
  for (int i = 0; i < 8; i++) {
 pinMode(pins[i], OUTPUT);
}
}

void seg::display(int num){
  int numbers[10][7] = {
{1, 1, 1, 1, 1, 1, 0},
{0, 1, 1, 0, 0, 0, 0},
{1, 1, 0, 1, 1, 0, 1},
{1, 1, 1, 1, 0, 0, 1},
{0, 1, 1, 0, 0, 1, 1},
{1, 0, 1, 1, 0, 1, 1},
{1, 0, 1, 1, 1, 1, 1},
{1, 1, 1, 0, 0, 0, 0},
{1, 1, 1, 1, 1, 1, 1},
{1, 1, 1, 1, 0, 1, 1}
};

  for (int i = 0; i < 7; i++) {
 digitalWrite(pins[i], numbers[num][i]);
 }
 }
