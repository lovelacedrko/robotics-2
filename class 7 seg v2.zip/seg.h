#ifndef SEG_H //if not defined
#define SEG_H 

#include <Arduino.h>

class seg{

  private:
int *pins; // ""int*"" means a pointer to a variable whose datatype is integer
 seg(){};


  public:
   seg(int pins[7]);

   void init();
   void display(int num);
   
};




#endif